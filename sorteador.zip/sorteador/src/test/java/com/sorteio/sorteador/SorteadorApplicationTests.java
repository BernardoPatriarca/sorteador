package com.sorteio.sorteador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SorteadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
